# Release checklist

- [ ] Confirm app name and app icon artwork
- [ ] Test navigation and dialogs on Android and desktop
- [ ] Confirm Firebase Firestore is enabled only if needed
- [ ] Set restrictive Firestore rules and test them
- [ ] Add a privacy policy and contact email
- [ ] Connect approved Catholic daily readings source
- [ ] Upload only licensed music/audio
- [ ] Test offline cache and favorites
- [ ] Configure reliable scheduled prayer notifications
- [ ] Test APK on a real Android device
- [ ] Review accessibility, contrast and font sizing
