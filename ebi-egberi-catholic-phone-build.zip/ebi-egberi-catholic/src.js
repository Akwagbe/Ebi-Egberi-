import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, serverTimestamp } from 'firebase/firestore';

// Firebase web configuration supplied for the Ebi Egberi Catholic project.
const firebaseConfig = {
  apiKey: 'AIzaSyB3kOZuMXZd1u1BYrIo6qM1DpQcg1sk5EU',
  authDomain: 'ebi-egberi-catholic.firebaseapp.com',
  projectId: 'ebi-egberi-catholic',
  storageBucket: 'ebi-egberi-catholic.firebasestorage.app',
  messagingSenderId: '667854101134',
  appId: '1:667854101134:web:af8254f1dfa78cf6d107df',
  measurementId: 'G-VYYDFXK4FT'
};

let db = null;
try { db = getFirestore(initializeApp(firebaseConfig)); } catch (error) { console.warn('Firebase not connected:', error); }

const prayers = {
  morning: { title: 'Morning Offering', body: 'O Jesus, through the Immaculate Heart of Mary, I offer You my prayers, works, joys and sufferings of this day, for all the intentions of Your Sacred Heart, in union with the Holy Sacrifice of the Mass throughout the world, for the salvation of souls, the reparation of sins, and the reunion of all Christians. Amen.' },
  night: { title: 'Night Prayer', body: 'Heavenly Father, thank You for guiding me through this day. Forgive my faults, heal the hurts I have caused, and bless everyone I love. Keep me safe through the night and renew my heart for tomorrow. May I rest in Your peace. Through Christ our Lord. Amen.' },
  strength: { title: 'Prayer for Strength', body: 'Loving Father, when I feel weak, remind me that Your grace is enough. Give me courage to face today, patience in difficulty, and hope when the way is unclear. Help me trust in You and show Your love to the people around me. Through Christ our Lord. Amen.' }
};
const dialog = document.querySelector('#contentDialog');
const dialogContent = document.querySelector('#dialogContent');
function showDialog(title, body) { dialogContent.innerHTML = `<h2>${title}</h2><p>${body}</p><button class="button dark" id="savePrayer">Save to favorites ♡</button>`; dialog.showModal(); document.querySelector('#savePrayer').addEventListener('click', () => { const item = { title, body }; const saved = JSON.parse(localStorage.getItem('ebiFavorites') || '[]'); if (!saved.some(x => x.title === title)) saved.push(item); localStorage.setItem('ebiFavorites', JSON.stringify(saved)); document.querySelector('#savePrayer').textContent = 'Saved ✓'; }); }
document.querySelectorAll('[data-prayer]').forEach(button => button.addEventListener('click', () => { const p = prayers[button.dataset.prayer]; showDialog(p.title, p.body); }));
document.querySelector('#dialogClose').addEventListener('click', () => dialog.close());
document.querySelector('#reflectionButton').addEventListener('click', () => showDialog('A moment to reflect', 'Take a slow breath. Ask yourself: What am I grateful for today? Who needs my kindness? What can I place in God’s hands? Spend a quiet minute listening in your heart, then close with the Sign of the Cross.'));
document.querySelector('#rosaryButton').addEventListener('click', () => showDialog('Begin the Holy Rosary', '1. Make the Sign of the Cross. 2. Pray the Apostles’ Creed. 3. Pray one Our Father. 4. Pray three Hail Marys. 5. Pray the Glory Be. 6. Announce the appropriate mystery and intention. Pray one Our Father, ten Hail Marys and the Glory Be for each decade. Conclude with the Hail Holy Queen. Choose the Joyful, Luminous, Sorrowful or Glorious Mysteries according to the day and your devotion.'));
document.querySelector('#reminderButton').addEventListener('click', async () => { if (!('Notification' in window)) { alert('Notifications are not supported in this browser. You can set a daily reminder in your phone clock for now.'); return; } const permission = await Notification.requestPermission(); if (permission === 'granted') { new Notification('Ebi Egberi Catholic', { body: 'Take a quiet moment for prayer today.' }); alert('Permission granted. This starter version can show a test notification, but scheduled daily reminders need additional setup.'); } else alert('Notifications were not enabled. You can enable them in your browser or phone settings.'); });
document.querySelector('#menuToggle').addEventListener('click', () => document.querySelector('#mainNav').classList.toggle('open'));
document.querySelectorAll('#mainNav a').forEach(a => a.addEventListener('click', () => document.querySelector('#mainNav').classList.remove('open')));
document.querySelector('#year').textContent = new Date().getFullYear();

// Optional feedback collection; Firestore security rules must be configured before production use.
window.submitAppFeedback = async (message) => {
  if (!db) throw new Error('Firebase is not available.');
  if (typeof message !== 'string' || !message.trim() || message.length > 1000) throw new Error('Enter feedback under 1,000 characters.');
  return addDoc(collection(db, 'feedback'), { message: message.trim(), createdAt: serverTimestamp() });
};

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('/service-worker.js').catch(console.warn);
