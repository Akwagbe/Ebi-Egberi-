# Ebi Egberi Catholic

A responsive Catholic prayer and reflection website starter designed for the Ebi Egberi Catholic brand. It uses a premium deep-green, gold and cream palette with subtle cultural styling, and is structured to be packaged for Android using Capacitor.

## Included in this starter
- Responsive website for phone and desktop
- Morning offering, night prayer and prayer for strength
- Rosary guide and Scripture reflection prompt
- Favorites saved in the browser on that device
- Basic offline caching for core website files
- Firebase project configuration and optional Firestore feedback function
- Capacitor Android packaging configuration

## Requirements
- Node.js 18 or newer
- npm
- Android Studio for building an Android APK
- A Google/Firebase account with access to the supplied Firebase project

## Run the website locally
1. Install Node.js from the official Node.js website.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run start`.
5. Open the local URL Vite prints in your browser.

## Build the website
Run `npm run build`. The deployable website files will be created in `dist/`.

## Prepare Android project
1. Install Android Studio and the Android SDK.
2. In this folder run `npm install`.
3. Run `npx cap add android` once.
4. Run `npm run android:sync`.
5. Run `npm run android:open` to open the project in Android Studio.
6. In Android Studio, test on an emulator or Android phone. Use Build > Build Bundle(s) / APK(s) > Build APK(s) to create a test APK.

The Android project is generated on your computer by Capacitor; the ZIP does not contain a prebuilt APK.

## Firebase setup and security
The supplied Firebase web configuration is included in `src.js`. Firebase web config values identify the project; they are not a substitute for security. Before production:
- Configure Firestore rules to deny public writes unless a specific safe use case requires them.
- Add Firebase Authentication if users need accounts or cloud-synced favorites.
- Configure authorized domains in Firebase Authentication if using sign-in.
- Enable only the Firebase products you actually need.
- Do not put service-account keys or other private credentials in this website.

The optional `submitAppFeedback` function writes to a Firestore `feedback` collection. It will fail unless Firestore is enabled and security rules explicitly allow appropriate writes. Do not enable unrestricted writes for production.

## Music and Mass readings
This starter intentionally contains no copyrighted music files. Only upload or stream recordings for which you own the rights or have explicit permission. Offline downloads also require appropriate rights. Before release, connect a licensed music source or administrator-managed licensed audio library.

The Scripture reflection shown is a short Bible verse, not a complete daily Mass reading service. Connect an authoritative Catholic lectionary source and confirm permissions before presenting daily readings as current. Do not rely on placeholder content for liturgical dates.

## Before publishing
- Add app icons and splash screens.
- Test on several Android screen sizes.
- Configure real scheduled notifications (the current reminder button only tests notification permission).
- Add a proper source for daily readings and licensed music.
- Add privacy policy, contact details, accessibility checks, and Firebase security rules.
- Test offline behavior and fix any issues before release.

## Project files
- `index.html` — page structure
- `styles.css` — responsive design
- `src.js` — interactions and Firebase setup
- `manifest.webmanifest` and `service-worker.js` — basic install/offline support
- `capacitor.config.json` — Android wrapper configuration

## Phone-only cloud APK build (GitHub Actions)
This project includes `.github/workflows/build-android.yml`. You can use GitHub from a phone to run a cloud build without Android Studio:
1. Create a GitHub account or sign in, then create a new repository named `ebi-egberi-catholic`.
2. Upload the contents of this project folder to the repository (including the hidden `.github` folder). Keep `package.json` at the repository root.
3. Open the repository's **Actions** tab and select **Build Ebi Egberi Catholic Android APK**.
4. Tap **Run workflow**. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the artifact named `ebi-egberi-catholic-debug-apk`. Extract it to get `app-debug.apk`.
6. Open the APK on your Android phone and allow installation from your browser or file manager if Android asks. Only install APKs you built or trust.

The debug APK is for testing, not a Play Store release. The website and APK still need testing and the production items listed above (licensed music, real daily readings, privacy policy, notification implementation, and Firebase security rules) before public release.
